setwd("C:\\Users\\Admin\\OneDrive\\Desktop\\IT24101206")
getwd()